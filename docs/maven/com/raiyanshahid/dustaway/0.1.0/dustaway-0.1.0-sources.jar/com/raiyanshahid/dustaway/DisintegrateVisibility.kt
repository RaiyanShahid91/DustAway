/*
 * Copyright 2026 Raiyan Shahid
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.raiyanshahid.dustaway

import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier

/**
 * Shows [content] while [visible] is true and turns it to dust when it becomes false. Becoming true
 * again restores it. The content is removed from composition (no leftover touch target) once the dust
 * has finished.
 *
 * @param onDisintegrated Called after the dust animation has completed.
 */
@Composable
public fun DisintegrateVisibility(
    visible: Boolean,
    modifier: Modifier = Modifier,
    state: DisintegrationState = rememberDisintegrationState(),
    onDisintegrated: () -> Unit = {},
    content: @Composable () -> Unit,
) {
    LaunchedEffect(visible) {
        if (visible) {
            state.restore()
        } else {
            state.disintegrate()
            if (state.isDisintegrated) onDisintegrated()
        }
    }
    if (!state.isDisintegrated) {
        Box(modifier.disintegrate(state)) { content() }
    }
}
